package com.caweco.esra.dao.access;

import org.tinylog.Logger;

import com.caweco.esra.business.func.rest.RestClientESRADB;
import com.caweco.esra.business.func.rest.RestUtil;
import com.caweco.esra.business.utils.CommonUtil;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.entities.saml.SamlCountry;

import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;


public class SamlCountryDAO
{
	
	public static void insert(SamlCountry country)
	{
		RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		WebTarget webTarget = restClient.getMethodTarget("/accesscontrol/ldapcountries/");
		
		Response response = webTarget.request().post(Entity.entity(country, MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
		
		String responseBody = response.readEntity(String.class);
		Logger.info(responseBody);
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" added the country "  + country.getCountryName() + " from the system" );
	}
}
