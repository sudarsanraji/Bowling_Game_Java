package com.caweco.esra.entities.questionnaire;

public class FreeTextQuestion extends Question
{
	
	public FreeTextQuestion()
	{
		super();
	}
	
	public FreeTextQuestion(
		final String questionText,
		final String helperText,
		final Boolean active,
		final Boolean standard,
		final boolean copyEnable)
	{
		super(questionText, helperText, active, standard, copyEnable);
	}
	
	public FreeTextQuestion copyNoRules()
	{
		final var copy = new FreeTextQuestion();
		copy.setActive(this.getActive());
		copy.setCategory(new QuestionCategory(this.getCategory()));
		copy.setHelperText(this.getHelperText());
		copy.setId(this.getId());
		copy.setInstructionText(this.getInstructionText());
		copy.setQuestionText(this.getQuestionText());
		copy.setStandard(this.getStandard());
		copy.setCopyEnable(this.getCopyEnable());
		return copy;
	}
}
