package com.caweco.esra.entities.access;

import java.util.HashSet;
import java.util.Set;

import com.caweco.esra.entities.ldap.LdapOrg;

/**
 * An {@link LdapOrg} object with additional information about the allowed sub-organizations (which are also
 * {@link LdapOrg} objects).
 */
public class AccessControlCompany extends LdapOrg
{
	public static AccessControlCompany New(final LdapOrg source)
	{
		final AccessControlCompany accessControlCompany = new AccessControlCompany(
			source.getDistinguishedName(), source.getDisplayName());
		accessControlCompany.setCnId(source.getCnId());
		return accessControlCompany;
	}
	
	private Set<LdapOrg> allowedDepartments = new HashSet<>();
	
	public AccessControlCompany()
	{
		super();
	}
	
	public AccessControlCompany(final String distinguishedName, final String displayName)
	{
		super(distinguishedName, displayName);
	}
	
	public Set<LdapOrg> getAllowedDepartments()
	{
		return new HashSet<>(this.allowedDepartments);
	}
	
	public boolean addAllowedDepartment(LdapOrg department) 
	{
		return allowedDepartments.add(department);
	}

	public boolean removeAllowedDepartment(LdapOrg department) 
	{
		return allowedDepartments.remove(department);
	}

	public boolean isDepartmentAllowed(LdapOrg department) 
	{
		return allowedDepartments.contains(department);
	}
	
	public void setAllowedDepartments(final Set<LdapOrg> allowedDepartments)
	{
		this.allowedDepartments = allowedDepartments;
	}
}
