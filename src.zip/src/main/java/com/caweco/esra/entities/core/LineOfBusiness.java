package com.caweco.esra.entities.core;

import java.util.Objects;

import com.caweco.esra.ui.interfaces.ComboBoxValue;
import com.rapidclipse.framework.server.resources.Caption;


public class LineOfBusiness implements ComboBoxValue
{
	private Integer	id;
	private String	name;
	private boolean	active;
	
	public LineOfBusiness()
	{
		super();
	}
	
	@Override
	public void setName(String name)
	{
		this.name = name;
	}
	
	@Caption("Line of Business")
	@Override
	public String getName()
	{
		return this.name;
	}
	
	@Override
	public Integer getId()
	{
		return this.id;
	}
	
	@Override
	public void setId(Integer id)
	{
		this.id = id;
	}
	
	@Override
	public void setActive(Boolean active)
	{
		this.active = active;
	}
	
	@Override
	public Boolean getActive()
	{
		return this.active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LineOfBusiness other = (LineOfBusiness) obj;
		return Objects.equals(id, other.id);
	}
	
	
}
