
package com.caweco.esra.entities.rest.monitoring;

public interface BvdInfoTypeB
{
	String getName();
	
	String getBvdId();
	
	String getCity();
	
	String getCountryIso();
}
