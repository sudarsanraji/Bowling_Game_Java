package com.caweco.esra.entities.questionnaire;

public class DateChooserQuestion extends Question
{
	
	public DateChooserQuestion()
	{
		super();
	}
	
	public DateChooserQuestion(
		final String questionText,
		final String helperText,
		final Boolean active,
		final Boolean standard,
		final Boolean copyEnable)
	{
		super(questionText, helperText, active, standard, copyEnable);
	}
	
	
	/**
	 * 
	 */
	public DateChooserQuestion copyNoRules()
	{
		final var copy = new DateChooserQuestion();
		copy.setActive(this.getActive());
		copy.setCategory(new QuestionCategory(this.getCategory()));
		copy.setHelperText(this.getHelperText());
		copy.setId(this.getId());
		copy.setInstructionText(this.getInstructionText());
		copy.setQuestionText(this.getQuestionText());
		copy.setStandard(this.getStandard());
		copy.setCopyEnable(this.getCopyEnable());
		return copy;
	}
	
}
