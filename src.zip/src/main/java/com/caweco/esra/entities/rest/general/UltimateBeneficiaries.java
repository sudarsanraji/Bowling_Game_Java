package com.caweco.esra.entities.rest.general;

import com.caweco.esra.entities.rest.monitoring.BvdInfoTypeA;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.rapidclipse.framework.server.resources.Caption;


@JsonSerialize(as = BvdInfoTypeA.class)
public class UltimateBeneficiaries implements BvdInfoTypeA
{
	private String	name;
	private String	bvdId;
	private String	type;
	private String	address;
	private String	city;
	private String	postcode;
	private String	country;
	private String	website;
	private String	isListed;
	
	public UltimateBeneficiaries()
	{
		// Empty Constructor for Framework
	}
	
	@Override
	@Caption("Name")
	public String getName()
	{
		return this.name;
	}
	
	public void setName(final String name)
	{
		this.name = name;
	}
	
	@Override
	@Caption("BvD ID")
	public String getBvdId()
	{
		return this.bvdId;
	}
	
	public void setBvdId(final String bvdId)
	{
		this.bvdId = bvdId;
	}
	
	@Caption("Type")
	public String getType()
	{
		return this.type;
	}
	
	public void setType(final String type)
	{
		this.type = type;
	}
	
	public String getAddress()
	{
		return this.address;
	}
	
	public void setAddress(final String address)
	{
		this.address = address;
	}
	
	@Override
	public String getCity()
	{
		return this.city;
	}
	
	public void setCity(final String city)
	{
		this.city = city;
	}
	
	public String getPostcode()
	{
		return this.postcode;
	}
	
	public void setPostcode(final String postcode)
	{
		this.postcode = postcode;
	}
	
	@Override
	@Caption("Country")
	public String getCountry()
	{
		return this.country;
	}
	
	public void setCountry(final String country)
	{
		this.country = country;
	}
	
	public String getWebsite()
	{
		return this.website;
	}
	
	public void setWebsite(final String website)
	{
		this.website = website;
	}
	
	@Caption("Listed")
	public String getIsListed()
	{
		return this.isListed;
	}
	
	public void setIsListed(final String isListed)
	{
		this.isListed = isListed;
	}
}
