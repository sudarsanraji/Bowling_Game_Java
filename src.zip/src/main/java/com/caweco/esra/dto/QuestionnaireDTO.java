package com.caweco.esra.dto;

import java.util.List;

import com.caweco.esra.entities.questionnaire.Question;
import com.caweco.esra.entities.questionnaire.QuestionCategory;
import com.caweco.esra.entities.questionnaire.QuestionnaireCategory;

public class QuestionnaireDTO {
	private Integer questionnaireID;
	private String description;
	private List<QuestionCategory> categories;
	private List<Question> questions;
	private Boolean active;

	private QuestionnaireCategory category;
	private int version;
	public Integer getQuestionnaireID() {
		return questionnaireID;
	}
	public void setQuestionnaireID(Integer questionnaireID) {
		this.questionnaireID = questionnaireID;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public List<QuestionCategory> getCategories() {
		return categories;
	}
	public void setCategories(List<QuestionCategory> categories) {
		this.categories = categories;
	}
	public List<Question> getQuestions() {
		return questions;
	}
	public void setQuestions(List<Question> questions) {
		this.questions = questions;
	}
	public Boolean getActive() {
		return active;
	}
	public void setActive(Boolean active) {
		this.active = active;
	}
	public QuestionnaireCategory getCategory() {
		return category;
	}
	public void setCategory(QuestionnaireCategory category) {
		this.category = category;
	}
	public int getVersion() {
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}
	
	
	
}
