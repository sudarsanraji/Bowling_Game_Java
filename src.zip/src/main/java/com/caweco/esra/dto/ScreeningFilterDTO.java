package com.caweco.esra.dto;

import java.util.HashSet;
import java.util.Set;

import com.caweco.esra.entities.core.Function;
import com.caweco.esra.entities.core.LineOfBusiness;
import com.caweco.esra.entities.core.OE;
import com.caweco.esra.entities.core.ScreeningStatus;

public class ScreeningFilterDTO {

	private Set<LineOfBusiness>		lobItems		= new HashSet<>();
	private Set<Function>			functionItems	= new HashSet<>();
	private Set<OE>					oeItems			= new HashSet<>();
	private Set<ScreeningStatus>	statusItems		= new HashSet<>();
	
	// Skip filtering if set to "false" (display "all")
	private boolean					byLOB			= false;
	private boolean					byFunction		= false;
	private boolean					byOE			= false;
	private boolean					byStatus		= true;
	
	public Set<LineOfBusiness> getLobItems() {
		return lobItems;
	}
	public void setLobItems(Set<LineOfBusiness> lobItems) {
		this.lobItems = lobItems;
	}
	public Set<Function> getFunctionItems() {
		return functionItems;
	}
	public void setFunctionItems(Set<Function> functionItems) {
		this.functionItems = functionItems;
	}
	public Set<OE> getOeItems() {
		return oeItems;
	}
	public void setOeItems(Set<OE> oeItems) {
		this.oeItems = oeItems;
	}
	public Set<ScreeningStatus> getStatusItems() {
		return statusItems;
	}
	public void setStatusItems(Set<ScreeningStatus> statusItems) {
		this.statusItems = statusItems;
	}
	public boolean isByLOB() {
		return byLOB;
	}
	public void setByLOB(boolean byLOB) {
		this.byLOB = byLOB;
	}
	public boolean isByFunction() {
		return byFunction;
	}
	public void setByFunction(boolean byFunction) {
		this.byFunction = byFunction;
	}
	public boolean isByOE() {
		return byOE;
	}
	public void setByOE(boolean byOE) {
		this.byOE = byOE;
	}
	public boolean isByStatus() {
		return byStatus;
	}
	public void setByStatus(boolean byStatus) {
		this.byStatus = byStatus;
	}
	
	
}
