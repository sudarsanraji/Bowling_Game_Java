package com.caweco.esra.business.func.data;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

import com.caweco.esra.business.func.filter.DarkActivityFilterUtil;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.core.SearchEntrySeaweb2Vessel;
import com.caweco.esra.entities.esra.seaweb2.ComplianceScreeningKeyData;
import com.caweco.esra.entities.rest.seaweb2.APSDarkActivityConfirmed_v2;
import com.caweco.esra.entities.rest.seaweb2.APSShipDetail_v2;

public class SeawebRedFlagCalculator
{
	private static final String SHIP_DARK_ACTIVITY_INDICATOR = "shipDarkActivityIndicator";
	
	static Map<String, Method> repo = new HashMap<>();
	
	private SeawebRedFlagCalculator()
	{
		// TODO Auto-generated constructor stub
	}
	
	/**
     * Main method to check if vessel has any red flags
     * Now includes dark activity filtering check
     */
    public static boolean hasRedFlag(Client cl, SearchEntrySeaweb2Vessel match)
    {
        if (match.getShipCount() < 1) {
            return false;
        }
        
        // Check standard compliance keys (excluding dark activity)
        if (hasStandardRedFlag(cl, match)) {
            return true;
        }
        
        // Check filtered dark activity records
        if (hasDarkActivityRedFlag(match)) {
            return true;
        }
        
        return false;
    }
    
    /**
     * Checks standard compliance screening keys
     * SKIPS dark activity indicator as it's handled separately
     */
    private static boolean hasStandardRedFlag(Client cl, SearchEntrySeaweb2Vessel match)
    {
        Map<String, ComplianceScreeningKeyData> activeKeys = cl.getSeaweb2ScreeningKeyConfig(false).stream()
            .filter(ComplianceScreeningKeyData::isActive)
            .filter(key -> StringUtils.isNotBlank(key.getKey()))
            // Skip dark activity - it's handled by hasDarkActivityRedFlag()
            .filter(key -> !SHIP_DARK_ACTIVITY_INDICATOR.equals(key.getKey()))
            .collect(Collectors.toMap(ComplianceScreeningKeyData::getKey, it -> it));
        
        APSShipDetail_v2 shipDetails = match.getShipDetails();
        
        for (ComplianceScreeningKeyData k : activeKeys.values())
        {
            if (!k.isActive())
                continue;
            
            int value = getIntValue(k.getKey(), shipDetails);
            if (value >= k.getMinValueForRed())
            {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Checks if filtered dark activity records indicate a red flag
     * 
     * A red flag is triggered if there are ANY filtered dark activity records
     * (i.e., records that pass all the filtering criteria)
     */
    public static boolean hasDarkActivityRedFlag(SearchEntrySeaweb2Vessel match)
    {
        if (match == null || match.getShipDetails() == null) {
            return false;
        }
        
        // Get filtered dark activity records
        List<APSDarkActivityConfirmed_v2> filteredRecords = 
            DarkActivityFilterUtil.filterDarkActivityRecords(match);
        
        // RED FLAG if there are ANY filtered records
        // GREEN FLAG if no filtered records exist
        return filteredRecords != null && !filteredRecords.isEmpty();
    }
		
//	public static boolean hasRedFlag(Client cl, SearchEntrySeaweb2Vessel match)
//	{
//		if (match.getShipCount() < 1) {
//			return false;
//		}
//		
//		Map<String, ComplianceScreeningKeyData> activeKeys = cl.getSeaweb2ScreeningKeyConfig(false).stream()
//			.filter(ComplianceScreeningKeyData::isActive)
//			.filter(key -> StringUtils.isNotBlank(key.getKey()))
//			.collect(Collectors.toMap(ComplianceScreeningKeyData::getKey, it -> it));
//		APSShipDetail_v2 shipDetails = match.getShipDetails();
//		
//		for (ComplianceScreeningKeyData k : activeKeys.values())
//		{
//			if (!k.isActive())
//				continue;
//			
//			int value = getIntValue(k.getKey(), shipDetails);
//			if (value >= k.getMinValueForRed())
//			{
//				return true;
//			}
//		}
//		
//		return false;
//	}
	
	
//	public static boolean hasRedFlag(Client cl, APSCompanyComplianceDetails_v2 item, Map<String, ComplianceScreeningKeyData> activeKeys)
//	{
//		// TODO: REWORK
//		Integer intValue_S = getIntValue_S(item.getCompanyOverallComplianceStatus());
//		!= null) {
//			
//		}
//		this.lblOWCODE2.setText(item.getOwCode());
//		
//		this.lblCompanyInFATFJurisdiction2.setText(item.getCompanyInFATFJurisdiction());
//		this.lblCompanyInOFACSanctionedCountry2.setText(item.getCompanyInOFACSanctionedCountry());
//		this.lblCompanyOnBESSanctionList2.setText(item.getCompanyOnBESSanctionList());
//		
//		this.lblCompanyOnEUSanctionList2.setText(item.getCompanyOnEUSanctionList());
//		this.lblCompanyOnOFACSanctionList2.setText(item.getCompanyOnOFACSanctionList());
//		this.lblCompanyOnUNSanctionList2.setText(item.getCompanyOnUNSanctionList());
//		
//		this.lblCompanyOnAustralianSanctionList2.setText(item.getCompanyOnAustralianSanctionList());
//		this.lblCompanyOnCanadianSanctionList2.setText(item.getCompanyOnCanadianSanctionList());
//		this.lblCompanyOnOFACSSIList2.setText(item.getCompanyOnOFACSSIList());
//		this.lblCompanyOnSwissSanctionList2.setText(item.getCompanyOnSwissSanctionList());
//		if (cce.getCompanyInFATFJurisdiction()
//		for (ComplianceScreeningKeyData k : activeKeys)
//		{
//			if (!k.isActive())
//				continue;
//			
//			int value = getIntValue(k.getKey(), shipDetails);
//			if (value >= k.getMinValueForRed())
//			{
//				return true;
//			}
//		}
//		
//		return false;
//	}
//	
//	public static boolean hasRedFlag(String key, String value, List<ComplianceScreeningKeyData> activeKeys)
//	{
//		cce.getCompanyInFATFJurisdiction()
//		for (ComplianceScreeningKeyData k : activeKeys)
//		{
//			if (!k.isActive())
//				continue;
//			
//			int value = getIntValue(k.getKey(), shipDetails);
//			if (value >= k.getMinValueForRed())
//			{
//				return true;
//			}
//		}
//		
//		return false;
//	}
	
    /**
     * Checks red flag for a specific key
     * Handles dark activity specially
     */
	public static boolean hasRedFlag_Key(SearchEntrySeaweb2Vessel match, ComplianceScreeningKeyData key)
	{
		if (!key.isActive())
			return false;
		
		// Special handling for dark activity indicator
	    if (SHIP_DARK_ACTIVITY_INDICATOR.equals(key.getKey())) {
	        // Use filtered dark activity records
	        return hasDarkActivityRedFlag(match);
	    }
	    
	    // Standard logic for other keys
		int value = getIntValue(key.getKey(), match.getShipDetails());
		if (value >= key.getMinValueForRed())
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	
	public static int getIntValue(String key, APSShipDetail_v2 item) {
		Integer value = -1;
		if (item.getProperties() != null && item.getProperties().containsKey(key)) {
			String stringvalue = item.getProperties().get(key);
			value = getIntValue_S(stringvalue);
		}
		else {
			Object objectValue = callGetter(item, key);
			value = getIntValue_O(objectValue);
		}
		return value == null ? -1 : value;
	}
	
	

	public static Integer getIntValue_S(String value)
	{
		if (value == null)
			return null;
		
		if (StringUtils.equalsIgnoreCase("Null", value))
			return null;
		
		try
		{
			int parsed = Integer.parseInt(value);
			return parsed;
		}
		catch (NumberFormatException e)
		{
			e.printStackTrace();
			return null;
		}
	}
	
	public static Integer getIntValue_O(Object value)
	{
		if (value == null)
			return null;
		String stringValue = value.toString();
		
		return getIntValue_S(stringValue);
		
	}
	
	
	@SuppressWarnings("unchecked")
	public static <T> T callGetter(final APSShipDetail_v2 obj, final String fieldName)
	{
		final Method method = repo.get(fieldName);
		
		if (method == null)
		{
			try
			{
				final PropertyDescriptor pd = new PropertyDescriptor(fieldName, APSShipDetail_v2.class);
				final Method readMethod = pd.getReadMethod();
				
				try
				{
					final Object value = readMethod.invoke(obj);
					repo.put(fieldName, readMethod);
					
					return value != null ? (T) value : null;
				}
				catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e)
				{
					throw new RuntimeException(e);
				}
			}
			catch (final IntrospectionException e)
			{
				throw new RuntimeException(e);
			}
		}
		
		try
		{
			final Object value = method.invoke(obj);
			return value != null ? (T) value : null;
		}
		catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e)
		{
			repo.remove(fieldName);
			throw new RuntimeException(e);
		}
	}
	
}
