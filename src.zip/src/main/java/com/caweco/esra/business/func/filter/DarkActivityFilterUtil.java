package com.caweco.esra.business.func.filter;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.tinylog.Logger;

import com.caweco.esra.entities.core.SearchEntrySeaweb2Vessel;
import com.caweco.esra.entities.rest.seaweb2.APSDarkActivityConfirmed_v2;

public class DarkActivityFilterUtil {
    
    // Valid ship types
    private static final Set<String> VALID_SHIP_TYPES = new HashSet<>(
        Arrays.asList("Tankers", "Bulk Carriers")
    );
    
    // Valid dark status codes
    private static final Set<Integer> VALID_DARK_STATUS = new HashSet<>(
        Arrays.asList(4096, 64, 32, 1, 256, 1024)
    );
    
    // Valid area IDs
    private static final Set<Integer> VALID_AREA_IDS = new HashSet<>(
        Arrays.asList(23, 7, 4, 21, 1, 10, 16, 5, 8, 25, 24, 15, 19, 20, 22, 3, 6, 0, 14)
    );
    
    /**
     * Filters dark activity records based on business rules
     * 
     * @param vessel The vessel containing ship details and dark activity records
     * @return Filtered list of dark activity records
     */
    public static List<APSDarkActivityConfirmed_v2> filterDarkActivityRecords(
            SearchEntrySeaweb2Vessel vessel) {
        
        if (vessel == null || vessel.getShipDetails() == null) {
            return List.of();
        }
        
        // Get ship type
        String shipType = vessel.getShipDetails().getShiptypeLevel2();
        
        // Check if ship type is valid
        if (!isValidShipType(shipType)) {
            return List.of();
        }
        
        // Get dark activity records
        List<APSDarkActivityConfirmed_v2> darkActivityRecords = 
            vessel.getShipDetails().getDarkActivityConfirmed();
        
        if (darkActivityRecords == null || darkActivityRecords.isEmpty()) {
            return List.of();
        }
        
        // Filter records based on criteria
        return darkActivityRecords.stream()
            .filter(DarkActivityFilterUtil::shouldKeepRecord)
            .collect(Collectors.toList());
    }
    
    /**
     * Determines if a dark activity record should be kept based on filtering criteria
     */
    private static boolean shouldKeepRecord(APSDarkActivityConfirmed_v2 record) {
        try {
            // Check Dark_Time (must be within last 12 months)
            if (!isDarkTimeWithin12Months(record.getDarkTime())) {
                return false;
            }
            
            // Check Dark_Status
            if (!isValidDarkStatus(record.getDarkStatus())) {
                return false;
            }
            
            // Check Dark_Hours (must be 0 or > 6)
            if (!isValidDarkHours(record.getDarkHours())) {
                return false;
            }
            
            // Check Area_Id
            if (!isValidAreaId(record.getAreaId())) {
                return false;
            }
            
            return true;
            
        } catch (Exception e) {
            Logger.warn("Error filtering dark activity record: " + e.getMessage(), e);
            return false;
        }
    }
    
    /**
     * Checks if ship type is valid (Tankers or Bulk Carriers)
     */
    private static boolean isValidShipType(String shipType) {
        if (StringUtils.isBlank(shipType)) {
            return false;
        }
        return VALID_SHIP_TYPES.contains(shipType.trim());
    }
    
    /**
     * Checks if dark time is within the last 12 months
     */
    private static boolean isDarkTimeWithin12Months(String darkTime) {
        if (StringUtils.isBlank(darkTime)) {
            return false;
        }
        
        try {
            // Parse the dark time
            LocalDateTime darkDateTime = parseDarkTime(darkTime);
            if (darkDateTime == null) {
                return false;
            }
            
            // Calculate 12 months ago from now
            LocalDateTime twelveMonthsAgo = LocalDateTime.now().minusMonths(12);
            
            // Check if dark time is after 12 months ago (i.e., within last 12 months)
            return darkDateTime.isAfter(twelveMonthsAgo) || darkDateTime.isEqual(twelveMonthsAgo);
            
        } catch (Exception e) {
            Logger.warn("Error parsing dark time: " + darkTime, e);
            return false;
        }
    }
    
    /**
     * Parses dark time string to LocalDateTime
     * Supports multiple date formats including DD/MM/YYYY and YYYY-MM-DD
     */
    private static LocalDateTime parseDarkTime(String darkTime) {
        if (StringUtils.isBlank(darkTime)) {
            return null;
        }
        
        try {
            // Define all supported date formats
            DateTimeFormatter[] formatters = {
                // DD/MM/YYYY formats (European style)
                DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"),
                DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"),
                
                // YYYY-MM-DD formats (ISO style)
                DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"),
                DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"),
                DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss"),
                
                // MM/DD/YYYY formats (US style)
                DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss"),
                DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm"),
                
                // ISO standard
                DateTimeFormatter.ISO_LOCAL_DATE_TIME
            };
            
            // Try each formatter
            for (DateTimeFormatter formatter : formatters) {
                try {
                    return LocalDateTime.parse(darkTime.trim(), formatter);
                } catch (DateTimeParseException e) {
                    // Try next formatter
                }
            }
            
            // If no formatter worked, log warning
            Logger.warn("Could not parse dark time with any known format: " + darkTime);
            return null;
            
        } catch (Exception e) {
            Logger.warn("Error parsing dark time: " + darkTime, e);
            return null;
        }
    }
    
    /**
     * Checks if dark status is valid
     */
    private static boolean isValidDarkStatus(String darkStatus) {
        if (StringUtils.isBlank(darkStatus)) {
            return false;
        }
        
        try {
            Integer statusCode = Integer.parseInt(darkStatus.trim());
            return VALID_DARK_STATUS.contains(statusCode);
        } catch (NumberFormatException e) {
            Logger.warn("Invalid dark status format: " + darkStatus, e);
            return false;
        }
    }
    
    /**
     * Checks if dark hours is valid (0 or > 6)
     */
    private static boolean isValidDarkHours(String darkHours) {
        if (StringUtils.isBlank(darkHours)) {
            return false;
        }
        
        try {
            Double hours = Double.parseDouble(darkHours.trim());
            return hours == 0.0 || hours > 6.0;
        } catch (NumberFormatException e) {
            Logger.warn("Invalid dark hours format: " + darkHours, e);
            return false;
        }
    }
    
    /**
     * Checks if area ID is valid
     */
    private static boolean isValidAreaId(String areaId) {
        if (StringUtils.isBlank(areaId)) {
            return false;
        }
        
        try {
            Integer id = Integer.parseInt(areaId.trim());
            return VALID_AREA_IDS.contains(id);
        } catch (NumberFormatException e) {
            Logger.warn("Invalid area ID format: " + areaId, e);
            return false;
        }
    }
}
