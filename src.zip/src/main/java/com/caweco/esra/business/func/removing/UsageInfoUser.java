package com.caweco.esra.business.func.removing;

import java.util.HashSet;
import java.util.Set;

import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.User;
import com.caweco.esra.entities.core.Screening;
import com.caweco.esra.entities.messaging.MessageGroup;

/**
 * Usage info of a user in a single client.
 *
 */
public class UsageInfoUser
{
	final Client   client;
	
	boolean        assigned                         = false;
	
	Set<Screening> userIsOwner                      = new HashSet<>();
	Set<Screening> userIsServiceUser                = new HashSet<>();
	Set<Screening> userIsEsuWorker                  = new HashSet<>();
	
	Set<Screening> userIsMessageGroupMember         = new HashSet<>();
	Set<Screening> userIsPublicMessageGroupFollower = new HashSet<>();
	
	public UsageInfoUser(final Client client, final User user, final Set<User> users)
	{
		super();
		this.client = client;
		this.assigned = users.contains(user);
	}
	
	public Client getClient()
	{
		return this.client;
	}
	
	public Set<Screening> getUserIsOwner()
	{
	    return new HashSet<>(this.userIsOwner);
	}
	
	public Set<Screening> getUserIsServiceUser()
	{
	    return new HashSet<>(this.userIsServiceUser);
	}
	
	public Set<Screening> getUserIsEsuWorker()
	{
	    return new HashSet<>(this.userIsEsuWorker);
	}
	
	public Set<Screening> getUserIsMessageGroupMember()
	{
	    return new HashSet<>(this.userIsMessageGroupMember);
	}
	
	public Set<Screening> getUserIsPublicMessageGroupFollower()
	{
	    return new HashSet<>(this.userIsPublicMessageGroupFollower);
	}
	
	/**
	 * Checks if user is
	 * <ul>
	 * <li>a screening owner or</li>
	 * <li>a screening service user or</li>
	 * <li>a ESU user of a screening</li>
	 * </ul>
	 * 
	 * @return
	 */
	public boolean isScreeningUser()
	{
		return (!this.userIsOwner.isEmpty() || !this.userIsEsuWorker.isEmpty() || !this.userIsServiceUser.isEmpty());
	}
	
	/**
	 * Checks if user is
	 * <ul>
	 * <li>a member of a {@link MessageGroup} or</li>
	 * <li>a follower of the public message group</li>
	 * </ul>
	 * 
	 * @return
	 */
	public boolean isMessagingUser()
	{
		return (!this.userIsMessageGroupMember.isEmpty() || !this.userIsPublicMessageGroupFollower.isEmpty());
	}
	
	/**
	 * Checks if user is
	 * <ul>
	 * <li>a screening owner or</li>
	 * <li>a screening service user or</li>
	 * <li>a ESU user of a screening or</li>
	 * <li>a member of a {@link MessageGroup} or</li>
	 * <li>a follower of the public message group</li>
	 * </ul>
	 * Uses {@link UsageInfoUser#isScreeningUser()} and {@link UsageInfoUser#isMessagingUser()}
	 * 
	 * @return
	 */
	public boolean isInUse()
	{
		final boolean inUse = (this.isScreeningUser() || this.isMessagingUser());
		return inUse;
	}
	
	public boolean isAssigned()
	{
		return this.assigned;
	}
}
