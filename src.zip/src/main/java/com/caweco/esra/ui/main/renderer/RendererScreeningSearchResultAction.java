
package com.caweco.esra.ui.main.renderer;

import java.util.Optional;

import com.caweco.esra.business.aa.AuthorizationUtil;
import com.caweco.esra.business.func.common.Notificator;
import com.caweco.esra.business.properties.Aria;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.business.utils.ReadonlyEvaluationUtil;
import com.caweco.esra.business.utils.UiHelper;
import com.caweco.esra.dao.core.ScreeningDAO;
import com.caweco.esra.dto.ScreeningMetadataBase;
import com.caweco.esra.entities.User;
import com.caweco.esra.entities.core.Screening;
import com.caweco.esra.entities.core.ScreeningStatus;
import com.caweco.esra.ui.dialogs.DialogConfirm;
import com.caweco.esra.ui.main.ShowReportPopup;
import com.caweco.esra.ui.main.helper.ScreeningSearchResult;
import com.caweco.esra.ui.sanctions.PageEsuAssessment;
import com.caweco.esra.ui.sanctions.PageFinancialScreening;
import com.flowingcode.vaadin.addons.ironicons.IronIcons;
import com.rapidclipse.framework.server.data.renderer.RenderedComponent;
import com.vaadin.flow.component.AttachEvent;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.router.RouterLink;


public class RendererScreeningSearchResultAction extends HorizontalLayout
	implements RenderedComponent<ScreeningSearchResult<ScreeningMetadataBase>>
{

	private static final long serialVersionUID = 1L;
	ScreeningSearchResult<ScreeningMetadataBase> item;
	Optional<Screening>                          scr_ = Optional.empty();
	
	public RendererScreeningSearchResultAction()
	{
		super();
		this.initUI();
		
		UiHelper.setAriaLabel(this.rlScreeningEdit, Aria.get("PageSanctionSearch_item_edit"));
		UiHelper.setAriaLabel(this.btnCreatePDF, Aria.get("PageSanctionSearch_item_pdfSummary"));
		UiHelper.setTitle(this.rlScreeningEdit, Aria.get("PageSanctionSearch_item_edit"));
		UiHelper.setTitle(this.btnCreatePDF, Aria.get("PageSanctionSearch_item_pdfSummary"));
	}
	
	@Override
	public void renderComponent(final ScreeningSearchResult<ScreeningMetadataBase> value)
	{
		this.item = value;
		User currentUser = CurrentUtil.getUser();
		 if(this.item.getStatus() == ScreeningStatus.IN_PROGRESS && this.item.getScreeningOwnerEmail().equals(CurrentUtil.getUser().getEmailAddress()))
		{
			this.btnDelete.setVisible(true);
			this.btnDelete.setEnabled(true);
		}
		else
		{
			this.btnDelete.setVisible(false);
			this.btnDelete.setEnabled(false);
		}
		
		final Optional<String> isReadonly = ReadonlyEvaluationUtil
			.evalEditableSetting_ESRA(CurrentUtil.getClient(), value, CurrentUtil.getUser());
		
		Button btnRL;
		
		 if (AuthorizationUtil.isAuditRoles(currentUser)) {
		    btnRL = new Button(VaadinIcon.EYE.create());
		    UiHelper.setTitle(btnRL, "Show (readonly)");
		    UiHelper.setAriaLabel(btnRL, "Show (readonly)");
		    btnRL.getElement().getStyle().set("color", "#5e5e5e");
		    btnRL.addThemeVariants(ButtonVariant.LUMO_TERTIARY, ButtonVariant.LUMO_SMALL);
		    this.btnDelete.setVisible(true);
		    this.btnDelete.setEnabled(false);	     
		}
		
		else if(isReadonly.isPresent())
		{
			btnRL = new Button(VaadinIcon.EYE.create());
			UiHelper.setTitle(btnRL, "Show (readonly)");
			UiHelper.setAriaLabel(btnRL, "Show (readonly)");
			btnRL.getElement().getStyle().set("color", "#5e5e5e");
			btnRL.addThemeVariants(ButtonVariant.LUMO_TERTIARY, ButtonVariant.LUMO_SMALL);
				 
		}
		else
		{
			btnRL = new Button(VaadinIcon.EDIT.create());
			UiHelper.setTitle(btnRL, "Edit");
			btnRL.addThemeVariants(ButtonVariant.LUMO_TERTIARY, ButtonVariant.LUMO_SMALL);

		}
		
		if(item.getStatus().getStatus().startsWith("Review"))
		{
			rlScreeningEdit.setRoute(PageEsuAssessment.class, this.item.getId());
			rlScreeningEdit.getElement().appendChild(btnRL.getElement());
		}
		else
		{
			rlScreeningEdit.setRoute(PageFinancialScreening.class, this.item.getId());
			rlScreeningEdit.getElement().appendChild(btnRL.getElement());
		}
		
		if(AuthorizationUtil.isAuditRoles(currentUser) && this.item.getStatus() == ScreeningStatus.IN_PROGRESS)
		{
			rlScreeningEdit.setRoute(PageEsuAssessment.class, this.item.getId());
			rlScreeningEdit.getElement().appendChild(btnRL.getElement());
		}
	}
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnCreatePDF}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnCreatePDF_onClick(final ClickEvent<Button> event)
	{
		if(this.scr_.isEmpty())
		{
			this.scr_ = this.item.fetchScreening();
		}
		
		if(this.scr_.isPresent())
		{
			new ShowReportPopup(this.scr_.get()).open();
		}
		else
		{
			Notificator.warn("Could not obtain full Screening");
		}
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnDelete}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnDelete_onClick(final ClickEvent<Button> event) {
		
        DialogConfirm.show(() ->
        {
        	
        	ScreeningDAO.deleteScreening(this.item.getClientId(), this.item.getId());
        	UI.getCurrent().getPage().reload();
        },
            "Delete case?",
            "Are you sure you want to delete the case? This action cannot be undone.");
	}
	
	/* WARNING: Do NOT edit!<br>The content of this method is always regenerated by the UI designer. */
	// <generated-code name="initUI">
	private void initUI()
	{
		this.rlScreeningEdit = new RouterLink();
		this.btnCreatePDF = new Button();
		this.btnDelete = new Button();
		
		this.setSpacing(false);
		this.btnCreatePDF.addThemeVariants(ButtonVariant.LUMO_SMALL, ButtonVariant.LUMO_TERTIARY);
		this.btnCreatePDF.setIcon(VaadinIcon.SEARCH.create());
		this.btnDelete.addThemeVariants(ButtonVariant.LUMO_SMALL, ButtonVariant.LUMO_TERTIARY, ButtonVariant.LUMO_ERROR);
		this.btnDelete.setIcon(IronIcons.DELETE.create());
		
		this.btnCreatePDF.setSizeUndefined();
		this.btnDelete.setSizeUndefined();
		this.add(this.rlScreeningEdit, this.btnCreatePDF, this.btnDelete);
		this.setSizeFull();
		
		this.btnCreatePDF.addClickListener(this::btnCreatePDF_onClick);
		this.btnDelete.addClickListener(this::btnDelete_onClick);
	} // </generated-code>

	// <generated-code name="variables">
	private Button		btnCreatePDF, btnDelete;
	private RouterLink	rlScreeningEdit;
	// </generated-code>
	
}
