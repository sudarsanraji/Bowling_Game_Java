
package com.caweco.esra.ui.main.helper;

import java.time.LocalDate;

import com.caweco.esra.dto.ScreeningMetadataBase;
import com.rapidclipse.framework.server.resources.Caption;


public interface ScreeningSearchResultEsu<T extends ScreeningMetadataBase> extends ScreeningSearchResult<T>
{
	@Caption("Unread Messages")
	public int getUnreadMessages();
	
	@Caption("Request Date")
	public LocalDate getScreeningEsuDate();
	
	@Caption("Inception Date")
	public LocalDate getInceptionDate();
	
	@Caption("Departure Date")
	public LocalDate getDepartureDate();
}
