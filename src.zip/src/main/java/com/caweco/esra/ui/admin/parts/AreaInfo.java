package com.caweco.esra.ui.admin.parts;

public class AreaInfo {
    private String areaName;
    private Integer areaId;
    
    // Default constructor (IMPORTANT for Vaadin)
    public AreaInfo() {
    }
    
    public AreaInfo(String areaName, Integer areaId) {
        this.areaName = areaName;
        this.areaId = areaId;
    }
    
    public String getAreaName() {
        return areaName;
    }
    
    public void setAreaName(String areaName) {
        this.areaName = areaName;
    }
    
    public Integer getAreaId() {
        return areaId;
    }
    
    public void setAreaId(Integer areaId) {
        this.areaId = areaId;
    }
    
    @Override
    public String toString() {
        return "AreaInfo{areaName='" + areaName + "', areaId=" + areaId + "}";
    }
}