package com.caweco.esra.ui.admin.parts;

public class DarkActivityStatus {
    private String darkActivity;
    private Integer darkStatus;
    
    public DarkActivityStatus(String darkActivity, Integer darkStatus) {
        this.darkActivity = darkActivity;
        this.darkStatus = darkStatus;
    }
    
    public String getDarkActivity() {
        return darkActivity;
    }
    
    public void setDarkActivity(String darkActivity) {
        this.darkActivity = darkActivity;
    }
    
    public Integer getDarkStatus() {
        return darkStatus;
    }
    
    public void setDarkStatus(Integer darkStatus) {
        this.darkStatus = darkStatus;
    }
    
    
    @Override
    public String toString() {
        return "DarkActivityStatus{darkActivity='" + darkActivity + "', darkStatus=" + darkStatus + "}";
    }
}
